fstest.o: ../../test/fstest.c ../../include/types.h \
 ../../include/kern/types.h includelinks/kern/machine/types.h \
 includelinks/machine/types.h ../../include/kern/errno.h \
 ../../include/kern/fcntl.h ../../include/lib.h ../../include/cdefs.h \
 opt-noasserts.h ../../include/uio.h ../../include/kern/iovec.h \
 ../../include/thread.h ../../include/array.h ../../include/spinlock.h \
 includelinks/machine/spinlock.h ../../include/threadlist.h \
 includelinks/machine/thread.h ../../include/setjmp.h \
 includelinks/kern/machine/setjmp.h ../../include/synch.h opt-shellc2.h \
 ../../include/vfs.h ../../include/fs.h ../../include/vnode.h \
 ../../include/test.h
