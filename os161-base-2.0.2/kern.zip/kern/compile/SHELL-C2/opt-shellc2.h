/* Automatically generated; do not edit */
#ifndef _OPT_SHELLC2_H_
#define _OPT_SHELLC2_H_
#define OPT_SHELLC2 1
#endif /* _OPT_SHELLC2_H_ */
