semfs_obj.o: ../../fs/semfs/semfs_obj.c ../../include/types.h \
 ../../include/kern/types.h includelinks/kern/machine/types.h \
 includelinks/machine/types.h ../../include/kern/errno.h \
 ../../include/synch.h ../../include/spinlock.h ../../include/cdefs.h \
 includelinks/machine/spinlock.h opt-shellc2.h ../../fs/semfs/semfs.h \
 ../../include/array.h ../../include/lib.h opt-noasserts.h \
 ../../include/fs.h ../../include/vnode.h
