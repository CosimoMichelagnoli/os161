fork.o: ../../syscall/fork.c ../../include/types.h \
 ../../include/kern/types.h includelinks/kern/machine/types.h \
 includelinks/machine/types.h ../../include/lib.h ../../include/cdefs.h \
 opt-noasserts.h ../../include/kern/errno.h ../../include/proc.h \
 ../../include/spinlock.h includelinks/machine/spinlock.h \
 ../../include/limits.h ../../include/kern/limits.h opt-shellc2.h \
 opt-file.h ../../include/copyinout.h ../../include/thread.h \
 ../../include/array.h ../../include/threadlist.h \
 includelinks/machine/thread.h ../../include/setjmp.h \
 includelinks/kern/machine/setjmp.h ../../include/current.h \
 includelinks/machine/current.h ../../include/addrspace.h \
 ../../include/vm.h includelinks/machine/vm.h opt-dumbvm.h \
 includelinks/mips/trapframe.h ../../include/synch.h \
 ../../include/syscall.h
