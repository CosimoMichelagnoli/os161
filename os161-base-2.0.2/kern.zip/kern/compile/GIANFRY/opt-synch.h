/* Automatically generated; do not edit */
#ifndef _OPT_SYNCH_H_
#define _OPT_SYNCH_H_
#define OPT_SYNCH 1
#endif /* _OPT_SYNCH_H_ */
