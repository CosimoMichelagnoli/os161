/* Automatically generated; do not edit */
#ifndef _OPT_WAITPID_H_
#define _OPT_WAITPID_H_
#define OPT_WAITPID 1
#endif /* _OPT_WAITPID_H_ */
