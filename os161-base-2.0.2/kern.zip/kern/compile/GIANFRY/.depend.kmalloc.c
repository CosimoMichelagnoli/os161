kmalloc.o: ../../vm/kmalloc.c ../../include/types.h \
 ../../include/kern/types.h includelinks/kern/machine/types.h \
 includelinks/machine/types.h ../../include/lib.h ../../include/cdefs.h \
 opt-noasserts.h ../../include/spinlock.h includelinks/machine/spinlock.h \
 ../../include/vm.h includelinks/machine/vm.h
